import { Component,OnInit } from '@angular/core';
import * as data from '../../../doc ingest/classification_results.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'doc-ingest-ui';
  products : any = (data as any).default;
  constructor(){

  } 
  ngOnInit(){
    console.log(data);
    this.products = data.default;
    
  }
}
